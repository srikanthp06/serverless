export default async function handler(req, res) {
  console.log("API request received");

  if (req.method !== "POST") {
    console.log("Method not allowed");
    return res.status(405).end();
  }

  const { message } = req.body;

  if (!process.env.OPENAI_API_KEY) {
    console.error("Missing OpenAI API key");
    return res.status(500).json({ reply: "Server error: Missing API key" });
  }

  try {
    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: message }]
      })
    });

    const data = await openaiRes.json();
    console.log("OpenAI API response:", data);

    const reply = data.choices?.[0]?.message?.content || "No reply";
    res.status(200).json({ reply });

  } catch (error) {
    console.error("Error talking to OpenAI:", error);
    res.status(500).json({ reply: "Server error: Failed to contact OpenAI" });
  }
}
